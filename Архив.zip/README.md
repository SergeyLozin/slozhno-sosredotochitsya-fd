https://github.com/SergeyLozin/slozhno-sosredotochitsya-fd
